import json
import argparse
from tqdm import tqdm
from GetResponse import GetResponse
from autorater_prompt import prompt_template

def safe_strip(value):
    """
    Strip whitespace from a string or return an empty string if the value is not a string.

    Args:
        value: The value to be stripped.

    Returns:
        str: Stripped string or empty string if value is not a string.
    """
    return str(value).strip() if isinstance(value, str) else ""

def auto_evaluator(question, gold_answer, model_output):
    """
    Evaluate the AI output against the gold answer using a predefined prompt template.

    Args:
        question (str): The question being answered.
        gold_answer (str): The correct answer to the question.
        model_output (str): The AI-generated answer to the question.

    Returns:
        tuple: Contains the response from the model, prompt token count, and completion token count.
    """
    model_name = "gpt-4o-2024-11-20"
    prompt_text = prompt_template.format(
        question=safe_strip(question),
        gold_answer=safe_strip(gold_answer),
        model_output=safe_strip(model_output),
    )
    response_content, prompt_tokens, completion_tokens, _ = \
    get_response.get_response(
         model_name, prompt_text
         )
    return response_content, prompt_tokens, completion_tokens

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run autorater evaluation.")
    parser.add_argument(
        "--input_path",
        type=str,
        default="data/autorater/Anthropic_CU_20250310.json",
        help="Path to the input JSON file containing questions and answers.",)
    args = parser.parse_args()
    
    output_path = args.input_path.replace(".json", "_autorated.json")

    get_response = GetResponse()

    with open(args.input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    prompt_tok_cnt = 0
    completion_tok_cnt = 0

    res_dict = {
        "correct": 0,
        "wrong": 0,
        "no_answer": 0,
        "no_direct_answer": 0,
    }

    for k, v in tqdm(data.items()):
        response, prompt_tok, completion_tok = auto_evaluator(
            v["question"], v["gold_answer"], v["model_answer"]
        )
        prompt_tok_cnt += prompt_tok
        completion_tok_cnt += completion_tok
        v["auto_evaluator_response"] = response.strip()

        res_dict[response.strip()] += 1

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

    print(f"Saved updated data with labels to: {output_path}")
    print(f"Total prompt tokens: {prompt_tok_cnt}")
    print(f"Total completion tokens: {completion_tok_cnt}")
    print("Label counts:")
    for label, count in res_dict.items():
        print(f"{label}: {count}")
