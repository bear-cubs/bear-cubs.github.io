import os
import tiktoken
from openai import OpenAI

class GetResponse():
    def __init__(self, max_tokens=518, temperature=0):
        # OpenAI model list: https://platform.openai.com/docs/models#gpt-4o
        self.max_tokens = max_tokens
        self.temperature = temperature

        # invariant variables
        self.tokenizer = tiktoken.encoding_for_model("gpt-4")

        # placeholder for model name
        self.model_name = None
        
        print(f"> Max tokens: {self.max_tokens}")
        print(f"> Temperature: {self.temperature}\n")
        
    def set_model(self, model_name):
        """
        Set the model and initialize the OpenAI client.

        Args:
            model_name (str): Name of the model to use.
        """
        self.model_name = model_name

        if "gpt" in self.model_name or "o1" in self.model_name:
            self.key = os.getenv("OPENAI_API_KEY")
            self.client = OpenAI(api_key=self.key)
            self.seed = 1130
        else:
            raise ValueError(f"Unsupported model: {self.model_name}")

    def get_response(
        self,
        model_name,
        prompt_text,
        system_message="You are a helpful assistant."
        ):
        """
        Generate a response using the specified model.

        Args:
            model_name (str): The model name.
            prompt_text (str): User prompt.
            system_message (str): System-level instruction.

        Returns:
            tuple: response text, prompt token count, completion token count, completion token details
        """
        self.set_model(model_name)
        if "gpt" in model_name or "o1" in model_name:
            return self._get_gpt_response(prompt_text, system_message)
        else:
            raise ValueError(f"Unsupported model name: {model_name}")

    def _get_gpt_response(self, prompt_text, system_message):
        """
        Internal method to call OpenAI's GPT-based models.

        Args:
            prompt_text (str): User prompt.
            system_message (str): System-level instruction.

        Returns:
            tuple: response text, prompt token count, completion token count, completion token details
        """
        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt_text}
        ]

        kwargs = {
            "model": self.model_name,
            "messages": messages,
            "seed": self.seed,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }

        response = self.client.chat.completions.create(**kwargs)
        content = response.choices[0].message.content.strip()
        usage = response.usage

        return (
            content,
            usage.prompt_tokens,
            usage.completion_tokens,
            getattr(usage, "completion_tokens_details", {})
        )