# Autorater

This tool uses GPT-based models to automatically rate model-generated answers against gold references for a given set of questions. It uses a custom prompt and retrieves scores via OpenAI's API.

## 📥 Input Format

Input should be a JSON file where each item follows this structure:

```json
{
  "q_id": {
    "question": "What is the capital of France?",
    "gold_answer": "Paris",
    "model_answer": "Lyon"
  }
}
```

Each `q_id` is a unique identifier for the question.

## 📝 Output Format

The output will be a JSON object with the same structure as the input, but with an additional field for the answer label (`no_answer`, `no_direct_answer`, `correct`, `wrong`):

```json
{
  "q_id": {
    "question": "What is the capital of France?",
    "gold_answer": "Paris",
    "model_answer": "Lyon",
    "auto_evaluator_response": "wrong"
  }
}
```

## ⚙️ Usage
To use the Autorater, you need to have Python installed along with the required libraries. You can install the necessary packages using pip:

```bash
pip install openai tiktoken tqdm
```

Make sure to set your OpenAI API key in your environment variables:

```bash
export OPENAI_API_KEY="your_api_key_here"
```

Then, you can run the Autorater script:

```bash
python autorater.py --input_path "path/to/input.json"
```

This will:
- Read the input JSON file.
- Process each question and its corresponding answers.
- Generate ratings using the OpenAI API.
- Output the results to a JSON file named `input_path.replace('.json', '_autorated.json')`.

## 🛠️ Notes

- GPT model used: `gpt-4o-2024-11-20`
- The script tracks token usage for prompt and completion
- Prompt format is fully customizable via autorater_prompt.py
- The script includes a progress bar for better user experience
- The output file will be saved in the same directory as the input file with `_autorated` appended to the filename.
