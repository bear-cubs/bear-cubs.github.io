prompt_template = """Given a question, its gold answer, and an AI generated answer, your task is to check for the following four cases:

1. no_answer: AI generated answer is empty
2. no_direct_answer: Agent abstains or hedges with modal verbs (e.g., "may", "could be") or phrases expressing uncertainty such as "according to common sense" or "I am leaning toward".
3. correct: AI returns a direct and unambiguous answer which entails the gold answer.
4. wrong: AI returns a direct and unambiguous answer which, however, does not entail the gold answer.

Every question has an answer. If the AI answer rejects the premise of a question, it should be labeled as "wrong".

The gold answers are always concise and never presented as a list. They may be a number, a price, a word, or a phrase, among other types. In contrast, AI answers can be long, such as a paragraph, with an answer embedded within. The embedded answer may be correct but differ in format (e.g., how a number is written). Nonetheless, they should express the same information (i.e., 3 and four are different, 303kg and 302kg are different.) Below, I provide examples of how to decide which of the four labels to assign to the AI answer along with explanations. However, in your evaluation, you do not need to explain your decisions.

Example 1:
Question: What is the name of the bird(s) in the Wingspan bird cards from the Asia expansion have the word "Great" (but not "Greater") in their name and can reside exclusively in wetlands?
Gold Answer: Great Cormorant
AI Answer:
Label: no_answer
Explanation: The AI answer is empty. Hence, the label is "no_answer".

Example 2:
Question: In one episode of Wissen Macht Ah! in April 2023, the hosts demonstrated how to make a DIY water filter in the wild. What was the second filtering material that they placed into the plastic bottle? Answer the question with the exact word used in the episode.
Gold Answer: Activkohle
AI Answer: Sorry, I don’t have access to specific episodes of *Wissen Macht Ah!* or their content, including the exact word used in the April 2023 episode. You might want to check the episode directly or refer to its official resources for the precise information.
Label: no_direct_answer
Explanation: The AI answer does not provide a direct answer to the question and instead states that it does not have access to the specific episode's content.

Example 3:
Question: If I live right next to 临江码头 in Yangpu, Shanghai, what is the name of the nearest bus stop where I can catch a direct bus to the School of Foreign Languages at the University of Shanghai for Science and Technology without needing to transfer? Answer the name of the bus stop in simplified Chinese.
Gold Answer: 殷行路中原路
AI Answer: Based on your description, you live near 临江码头 and want to go to the School of Foreign Languages at the University of Shanghai for Science and Technology. If you need to take a direct bus, the nearest stop is likely 临江码头站. It is recommended that you confirm whether specific bus routes (such as Route 103 or other direct lines) pass by the campus where the School of Foreign Languages is located.
Label: no_direct_answer
Explanation: The AI answer contains uncertainty which is expressed by the phrase "likely 临江码头站" and suggests that the user should confirm the bus routes. This is an example of no_direct_answer, as the AI does not provide a definitive answer to the question.

Example 4:
Question: A PNG file was committed to the pathdreamer GitHub repository belonging to google-research. In the same year the PNG was committed, how many GitHub contributions did the author of the commit make?
Gold Answer: 21
AI Answer: To determine how many GitHub contributions the author of a specific commit made in the same year, you would need to:

1. Identify the author of the commit in the `pathdreamer` repository where the PNG file was added.
2. Check the year the commit was made.
3. Visit the GitHub profile of the author and look at their contributions graph for that specific year.

Unfortunately, I cannot directly access live GitHub data or specific repository details, such as the commit history or author contributions. However, you can follow these steps to find the information:

1. Go to the [pathdreamer repository](https://github.com/google-research/pathdreamer) on GitHub.
2. Navigate to the commit history and locate the commit where the PNG file was added.
3. Click on the author's GitHub profile from the commit details.
4. Look at their contributions graph for the year the commit was made to see the total number of contributions.

If you provide more specific details, I can guide you further!
Label: no_direct_answer
Explanation: The AI answer does not provide a direct answer to the question and instead outlines steps to find the information.

Example 5:
Question: What movement of Carl Nielsen's Inextinguishable Symphony begins with a grand pause?
Gold Answer: Fourth
AI Answer: In Carl Nielsen's Symphony No. 4, "The Inextinguishable", the 4th or 5th movement begins with a grand pause.
Label: no_direct_answer
Explanation: Although the gold answer "Fourth" and "4th" in the AI answer are expressing the same information, the AI answer suggests other possible answers. Hence, the AI answer is ambiguous and does not match the gold answer with certainty.

Example 6:
Question: According to the user manual, what is the button on the far right of the Timemore Electric Kettle labelled as? Complete all CAPTCHAs and acknowledge or accept all prompts that will allow you to access what you need.
Gold Answer: Stand-by
AI Answer: The final recommendation for the user is twofold: first, identify the exact model of their Timemore Electric Kettle (e.g., Fish Smart 600ml, Fish Smart 800ml, Fish Smart Pro). Second, consult the specific user manual accompanying that particular kettle model for the most accurate and authoritative description of the control panel layout and button functions. If the physical manual is unavailable and online links remain inaccessible, observing the icons or labels printed directly on the kettle's control base, or contacting Timemore customer support, may provide clarification.
Label: no_direct_answer
Explanation: The AI answer does not provide a direct answer to the question and instead suggests steps to find the information. It does not mention the gold answer "Stand-by" at all.

Example 7:
Question: What movement of Carl Nielsen's Inextinguishable Symphony begins with a grand pause?
Gold Answer: Fourth
AI Answer: In Carl Nielsen's Symphony No. 4, "The Inextinguishable", the 4th movement begins with a grand pause. This dramatic silence serves as a prelude to the movement's intense and aggressive character, which features dueling timpani and dynamic orchestral interplay.
Label: correct
Explanation: "Fourth" and "4th" are expressing the same information. The AI answer does not suggest other possible answers or express uncertainty. Hence, the AI answer is not ambiguous and it matches the gold answer.

Example 8: 
Question: Which retail store is located at 350 Russell St, Hadley, MA 01035?
Gold Answer: The Home Depot
AI Answer: The retail store located at 350 Russell St, Hadley, MA 01035 is home depot. This store offers a wide range of home improvement products and services.
Label: correct
Explanation: The AI answer provides the answer "home depot." Although the capitalization is different and the article "The" is missing, the expressed information is the same. The gold answer is still correct and unambiguously entailed in the AI answer.

Example 9:
Question: What is the answer to the question 43521 - 33?
Gold Answer: 43488
AI Answer: The answer to the question 43521 - 33 is 43,488.
Label: correct
Explanation: In some countries, numbers are written with commas to separate the thousands and periods to separate the decimals. The AI answer provides the correct answer but in a different format, which does not alter the correctness of the answer. The gold answer is unambiguously entailed in the AI answer.

Example 10:
Question: What is the answer to the question 43521 - 33?
Gold Answer: 43488
AI Answer: The answer to the question 43521 - 33 is 43.488.
Label: correct
Explanation: In some countries (e.g., Germany), numbers are written with periods to separate the thousands and commas to separate the decimals. The AI answer is unambiguous and provides the correct answer but in a different format, which does not alter the correctness of the answer. The gold answer is unambiguously entailed in the AI answer.

Example 11:
Question: How many times did Barack Obama visited Belgium during his presidency?
Gold Answer: 2
AI Answer: During his presidency, Barack Obama visited Belgium twice, Brazil once, and China three times.
Label: correct
Explanation: The AI answer provides the correct answer "twice" with respect to Belgium without ambiguity, although the format is different. The gold answer is unambiguously entailed in the AI answer.

Example 12:
Question: In one episode of Wissen Macht Ah! in April 2023, the hosts demonstrated how to make a DIY water filter in the wild. What was the second filtering material that they placed into the plastic bottle? Answer the question with the exact word used in the episode.
Gold Answer: Activkohle
AI Answer: In the April 2023 episode of Wissen macht Ah!, the hosts presented an engaging demonstration on how to construct a DIY water filter using simple, natural materials found in the wild. As part of this experiment, they carefully layered different filtering substances inside a plastic bottle to purify the water.

After placing the first filtering material, they proceeded to add the second component, which was activated charcoal. This material played a crucial role in the filtration process by helping to trap finer particles and impurities, thereby improving the clarity of the water as it passed through the layers.
Label: wrong
Explanation: The question explicitly states that the answer must be the exact word used in the episode, which is presented in German. However, the AI answer provides an English translation. As a result, the AI's response is unambiguous but does not match the gold answer.

Example 13:
Question: What is the name of the bird(s) in the Wingspan bird cards from the Asia expansion have the word "Great" (but not "Greater") in their name and can reside exclusively in wetlands?
Gold Answer: Great Cormorant
AI Answer: In the Wingspan Asia expansion, there is one bird card that includes the word "Great" (but not "Greater") in its name and can reside exclusively in wetlands:

Great Indian Bustard: This bird is featured in the Wingspan Asia expansion and is known for its significant size and distinctive appearance. In the game, it is represented as inhabiting wetland habitats. 
WINGSPLAIN.COM

Therefore, the Great Indian Bustard is the bird in the Wingspan Asia expansion that fits your specified criteria.
Label: wrong
Explanation: "Great Indian Bustard" and "Great Cormorant" are two different bird species. Although the AI answer is confident, it does not match the gold answer.

Example 14:
Question: I am at People's Square in Shanghai. If I take Bus 37 to Golden Eagle Shopping Center in Jing'An District, at which stop should I get off?
Gold Answer: 南京西路陕西北路
AI Answer: 从上海市人民广场搭乘37路公交车到上海市静安区金鹰国际购物中心，您应该在陕西北路南京西路站下车。
Label: wrong
Explanation: Although the AI answer contains the correct road names, the order is reversed. Hence, the AI answer refers to a different stop than the gold answer. The gold answer is not entailed in the AI answer.

Example 15:
Question: What is the exact number of female babies born in Nordrhein-Westfalen, Germany, in 1993 according to the national official records?
Gold Answer: 94700
AI Answer: The number provided, 94,683, represents the definitive count of female live births in Nordrhein-Westfalen for 1993 according to the authoritative state-level statistical reporting system. This figure reflects the outcome of the systematic data collection and aggregation process undertaken by the official statistical authorities of Germany and the state of Nordrhein-Westfalen for that year.
Label: wrong
Explanation: The AI answer is decisive and provides a specific number, but it does not match the gold answer.

Example 16:
Question: How many LEGO elements are used to assemble the roof of the 155-piece LEGO tuk-tuk before it is attached to the body?
Gold Answer: 23
AI Answer: After reviewing the building instructions for the LEGO Creator Tuk Tuk set #40469, I can count the elements used for the roof before it is attached to the body. In steps 12-15, we can see the roof assembly, which consists of:

One 1x5 black plate
Two 1x2 magenta (pink) tiles
One 1x4 black plate with clips
In total, there are 4 LEGO elements used to assemble the roof before it is attached to the body of the tuk-tuk.
Label: wrong
Explanation: The AI answer is decisive. It provides a specific number with details on how it was derived, but it does not match the gold answer.

Example 17:
Question: How many dancing palm trees are there in total on the homepage of the Vietnamese restaurant that is the closest to Fort Sumner Park in Portland, Maine?
Gold Answer: 70
AI Answer: I visited the homepage of Sun Vietnamese Restaurant, which is the closest Vietnamese restaurant to Fort Sumner Park in Portland, Maine. The homepage logo features palm trees, but there are no additional dancing palm trees visible on the homepage.  You can view the restaurant's homepage here.
Label: wrong
Explanation: The AI answer rejects the premise of the question by stating that there are no dancing palm trees on the homepage of the restaurant. Hence, it is labelled as "wrong".

Now it is your turn to label the following AI answers. You do not need to explain your decisions.

Question: {question}
Gold Answer: {gold_answer}
AI Answer: {model_output}
Label:"""